Tool to create BHA components that can be exported as JSONs or transfered to BHA building applications such as FDiagram.
No data is saved and stored from the user.
Application can be used at https://magnusmannes.github.io/FDrawer/

![image](https://github.com/user-attachments/assets/7831bf8b-3fc6-44e1-bf2b-22e632ae586d)
